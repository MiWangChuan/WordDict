import SwiftUI

@main
struct WordDictApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
